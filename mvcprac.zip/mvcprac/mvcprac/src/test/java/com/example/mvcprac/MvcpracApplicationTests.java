package com.example.mvcprac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcpracApplicationTests {

	@Test
	void contextLoads() {
	}

}
