package com.example.mvcprac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcpracApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcpracApplication.class, args);
	}

}
