package com.example.mvcprac.service;

import com.example.mvcprac.model.Employee;

public interface EmployeeService {
    Employee saveEmployee(Employee employee);
}
